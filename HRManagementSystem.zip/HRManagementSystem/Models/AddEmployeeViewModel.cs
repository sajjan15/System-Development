﻿namespace NovaGamesDB.Models
{
    public class AddEmployeeViewModel
    {
        public string UserPassword { get; set; }
        public string UserRole { get; set; }

        public string Department { get; set; }

        public string Name { get; set; }
        public string Email { get; set; }
    }
}
