﻿namespace HRManagementSystem.Models
{
    public class User
    {
        public int Uid { get; set; }
        public string UserPassword { get; set; }
        public string UserRole { get; set; }
    }

}
